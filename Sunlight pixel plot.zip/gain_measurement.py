import matplotlib.pyplot as plt
import numpy as np

x = [404.043017578, 2459, 38282, 32086]
y = [6106, 52687466, 598123916, 276055502]

# Order = Hydrogen, Neon, Incandescent, Sunlight

x = np.array(x)
y = np.array(y)

A = np.vstack([x, np.ones(len(x))]).T
m, c = np.linalg.lstsq(A, y)[0]

plt.scatter(x, y)
plt.plot(x, m*x + c, 'r', label='Fitted line')

print(m,c)

plt.xlabel('Mean')
plt.ylabel('Variance')
plt.title('Gain of the spectrometer. y = 12852.236X - 3577420')
plt.show()

plt.show()