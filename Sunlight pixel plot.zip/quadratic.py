import matplotlib.pyplot as plt
import numpy as np
from numpy.polynomial import Polynomial

x_hydrogen = [637.5968752,909.624593,1690.550997]
y_hydrogen = [434, 486, 656]

x_neon = [1222.376781, 1240.708474, 1280.402003,1299.756069,1334.799973,1363.240315,1377.283604,1408.173918,1420.823436,1456.123636,1489.071846,1514.582629,1533.995697,1566.872525,1579.909348,1650.99691,1669.134823,1715.107661,1771.145902,1798.445155,1953.348463,2030.999854]
y_neon = [5852.49, 5881.89, 5944.83, 5975.53, 6030.00, 6074.34, 6096.16, 6143.06, 6163.59, 6217.28, 6304.79, 6334.43, 6382.99, 6402.25, 6506.53, 6532.88, 6598.95, 6678.28, 6717.04, 6929.47, 7032.41, 7173.94]

x = [637.5968752,909.624593,1690.550997,1222.376781, 1240.708474, 1280.402003,1299.756069,1334.799973,1363.240315,1377.283604,1408.173918,1420.823436,1456.123636,1489.071846,1514.582629,1533.995697,1566.872525,1579.909348,1650.99691,1669.134823,1715.107661,1771.145902,1798.445155,1953.348463,2030.999854]
y = [434, 486, 656, 5852.49, 5881.89, 5944.83, 5975.53, 6030.00, 6074.34, 6096.16, 6143.06, 6163.59, 6217.28, 6304.79, 6334.43, 6382.99, 6402.25, 6506.53, 6532.88, 6598.95, 6678.28, 6717.04, 6929.47, 7032.41, 7173.94]

# coefs = np.polynomial.polynomial.polyfit(x, y, 2)
# # ffit = np.poly1d(coefs)
# ffit = np.poly(coefs)
# x_new = np.linspace(x[0], x[-1], num=len(x)*10)
# fig1 = plt.figure()
# ax1 = fig1.add_subplot(111)
# ax1.scatter(x, y, facecolors='None')
# ax1.plot(x_new, ffit(x_new))
# plt.show()

def calc_yhat(x):
    # return 5723.52592538 + 1961.10180498*x -2588.66548234*(x**2) + 1694.0955231*(x**3)
    return (-.000249473*(x**2) + .000316045*x + .000558080)

p = Polynomial.fit(x, y, 2)
plt.plot(x, y, 'o', label='Original data', markersize=10)
y_hat = []
for val in x:
    y_hat.append(calc_yhat(val))
print(y_hat)
# plt.plot(x, y_hat, 'x', label='Data data', markersize=10)
plt.plot(*p.linspace())
plt.legend()
plt.xlabel('Pixel Value')
plt.ylabel('Intensity')
title = 'Cubic least squared fit (5723.52592538x^3 + 1961.10180498x^2 -2588.66548234x + 1694.0955231) '
plt.title(title)
plt.show()

# # plt.plot(x, y, 'o', label='Original data', markersize=10)
# plt.plot(x, y - (m*x + c), 'o', label='Diff data', markersize=10, color='r')
# # plt.plot(x, [0,0,0,0,0,0,0,0,0,0,0,00], 'r', label='Fitted line')
# # plt.plot(x, m*x + c, 'r', label='Fitted line')
# plt.legend()
# plt.xlabel('Pixel Value')
# plt.ylabel('Residuals')
# title = 'Residuals for linear least squared'
# plt.title(title)
# plt.show()
