import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

os.chdir('C:\\Users\\182362434\\Documents\\Docs\\@Archive\\Personal\\Github Repos\\Tutoring\\Python\\Assignments\\Alexander_Astronomy\\Lab-3\\NeonIT100')

with open("NeonIT100_000.txt", "r") as f:
    lines = f.readlines()

lines = lines[17:2065]
temp = []
data = []
for line in lines:
    temp.append(line.split())

for single_temp in temp:
    data.append([float(single_temp[0]), float(single_temp[1])])

sumxy = 0
sumy = 0
for i in data[1687:1695]:
    sumxy = float(i[0])*float(i[1]) + sumxy
    sumy = float(i[1]) + sumy
print(sumxy/sumy)

df_data = pd.DataFrame(data)

print(data[1][634:642])


plt.plot(df_data[0], df_data[1])
df_data_val = df_data[1].values
print(np.mean(df_data_val)) # 404.043017578
print(np.var(df_data_val)) # 6106.31167615

# plt.xlabel('Pixels')
# plt.ylabel('Intensity')
# plt.title('Hydrogen Pixel Plot')
# plt.show()